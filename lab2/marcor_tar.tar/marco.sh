v=$(pwd)
